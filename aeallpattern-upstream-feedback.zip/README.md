# AE All Pattern 0.1.0 兼容性修复反馈

适用环境：NeoForge 1.21.1、AE2 19.2.17、`aeallpattern-1.21.1-neoforge-0.1.0`。

本压缩包包含 GoldenTweaks 在大型 EMI + TooManyRecipeViewers 整合包中对 AE All Pattern 所做的兼容和性能修复。源码目前仍使用 GoldenTweaks 包名，合并到原模组前需要调整包名和 Mixin 配置。

## 1. EMI + TMRV 环境下生成聚合样板

相关文件：

- `compat/aeallpattern/EmiAggregateScanner.java`
- `mixin/fix/aeallpattern/ClientJeiAggregateScannerMixin.java`

实际遇到的问题：

- TMRV 的 JEI 桥接层可能无法为机器返回可用的 JEI 配方分类，生成器会提示“JEI 中没有可以编码为 AE 样板的配方”。
- TMRV 的槽位控件中保存的是 EMI 原料，普通的 JEI 原料流不一定能取得完整内容。
- Mekanism 化学品必须保留其已注册的 JEI 原料类型，才能交给 AE2 JEI Integration 转换为 AE `GenericStack`。
- 机器存在 1000 个以上配方时，如果在右键事件中同步转换全部配方，会明显阻塞渲染线程。

当前实现直接扫描 EMI 的工作站和配方分类，将物品、流体以及 TMRV 自定义原料转换为 AE `GenericStack`，然后继续使用 AE All Pattern 原有的 `GenerateAggregatePayload`，每页发送 128 个配方。

性能方面，主线程只获取候选配方快照，耗时的原料和输出转换放到后台线程执行，完成后再回到客户端线程发送数据包。同时使用单任务锁避免连续右键启动多个大型扫描任务。

对于原版合成、切石和锻造配方，必须使用 `getBackingRecipe()` 返回的真实 `RecipeHolder` ID，并根据服务端真实配方类确定样板类型。没有服务端 backing recipe 的 EMI 展示配方则降级为处理样板，否则服务端无法根据错误或虚构的配方 ID 重新编码。

原版工作台扫描还需要跳过 `Recipe.isSpecial()` 的动态特殊配方，例如旗帜复制、地图复制和烟花配方。这些配方的结果依赖实际合成输入，并不具有可预编码的固定输入输出；其中部分物品组件还持有临时注册表的 Holder，直接写入网络包会因找不到当前连接中的注册表 ID 而断开客户端。

仅检查具体配方类型或已知数据组件无法覆盖 Silent Gear 等模组的自定义材料和动态组件。当前实现使用客户端连接实际采用的 `RegistryAccess` 和 `ConnectionType`，通过 `AggregateRecipe.STREAM_CODEC` 在内存缓冲区中逐个预编码候选配方。编码成功才允许进入上传列表；任何注册表 Holder、数据组件或第三方原料编码失败都只跳过当前配方，不会中断整台机器的扫描或导致客户端掉线。预编码同样在后台扫描线程执行。

## 2. 聚合样板放入样板供应器后 AE 无法读取

相关文件：

- `mixin/fix/aeallpattern/PatternProviderLogicMixin.java`
- `compat/aeallpattern/TechStartPatternCompat.java`

AE All Pattern 原有的供应器 Mixin 会在 `ICraftingProvider.requestUpdate` 前将聚合占位样板替换为实际子样板。没有其它冲突 Mixin 时，这一思路可以正常工作。

但生产整合包中的 `sampleintegration-1.0.8+1.21.1` 对 `PatternProviderLogic.updatePatterns()` 使用了以下处理：

1. 在方法 `HEAD` 注入。
2. 清空并重新构建全部 `patterns` 和 `patternInputs`。
3. 自行调用 `requestUpdate`。
4. 无条件调用 `ci.cancel()`。

因此，AE All Pattern 位于方法后半段或 `requestUpdate` 前的注入永远不会执行。即使样板供应器中完全没有 SampleIntegration 样板，它也仍会取消整个 AE2 方法。

压缩包中的兼容实现以更早的注入顺序接管一次完整刷新，并按以下顺序处理：

1. SampleIntegration/TechStart 自定义样板展开。
2. AE All Pattern 聚合样板展开。
3. 普通 AE2 样板解码。
4. 重建 `patternInputs`。
5. 只通知一次 AE 合成网络。

建议 AE All Pattern 上游不要完整覆盖或取消 AE2 的整个刷新方法，而是只处理自己的聚合占位样板，并保证重复执行不会产生重复子样板。

此外，大型聚合样板可能包含成千上万个无法被 AE2 解码的第三方子配方。`AE2 rejected aggregate child pattern` 不应逐条输出，否则会产生数万行日志并严重卡顿，当前实现直接静默拦截；真正抛出异常的 `Failed to expand aggregate child` 则降为 DEBUG。建议上游直接调整日志策略，或只在扫描结束后输出一次汇总数量。

SampleIntegration 的 Mixin 也建议修改：不要在 `HEAD` 完整重建并无条件取消 `updatePatterns()`，否则会破坏其它所有自定义 AE 样板模组的兼容。

## 3. NeoECOAE / ECO-FD 智能样板总线

相关文件：

- `mixin/fix/aeallpattern/ECOCraftingPatternBusBlockEntityMixin.java`

智能样板总线只接受和注册 `IMolecularAssemblerSupportedPattern`。聚合样板物品初次通过 `PatternDetailsHelper.decodePattern()` 得到的是聚合占位对象，因此即使其内部包含普通合成样板，也会在插入过滤和样板列表刷新阶段被排除。

兼容实现允许聚合样板物品插入，并在刷新时把聚合中的每个 `IMolecularAssemblerSupportedPattern` 子样板加入总线原有列表。槽位过滤器会在客户端、服务端以及 Shift 快捷转移寻找目标槽位时被反复调用，因此该判断必须保持 O(1)，只能检查聚合样板数据组件，不能在此处调用 `AggregatePatternExpander.expand()`。否则包含上千个子配方的聚合样板会被重复完整展开，单次服务器 tick 可阻塞 40 秒以上。完整展开只应在物品已经放入后的样板列表刷新阶段执行一次。处理子样板不会加入该总线，执行阶段继续使用 NeoECOAE 原有逻辑。

## 4. 连接器距离和维度限制

相关文件：

- `mixin/fix/aeallpattern/ContextMixin.java`

整合包需要连接器与目标机器在不同维度或任意距离下工作，只要求两端区块均已加载。当前实现仅放宽 `sameDimension()` 和 `withinRange()`，其它所有权、区块加载、指纹、AE 网络在线状态、机器支持与占用验证仍由 AE All Pattern 处理。

这一项属于可选行为调整，并非所有玩家都需要。建议原模组将“允许跨维度”和“取消距离限制”分别做成服务端配置。

## 5. 天枢样板路由器界面高度

相关文件：

- `mixin/fix/aeallpattern/ClientEventsMixin.java`
- `assets/ae2/screens/goldentweaks_tianshu_priority.json`

天枢界面当前直接注册 AE2 的 `/screens/priority.json`。该样式使用固定的 176×125 背景纹理。

如果在 `init()` 结束后才把 `imageHeight` 增加 20，界面不会被正确扩展，因为：

- `topPos` 已经按照旧高度完成居中计算。
- 控件和逻辑边界已经根据旧高度初始化。
- 固定背景纹理本身仍然只有 125 像素高。
- 窗口缩放或重新初始化时还可能重复增加高度。

当前修复为天枢界面注册独立的 AE2 生成式背景样式，尺寸为 176×145。这样实际背景、逻辑边界和居中位置完全一致。

建议上游将该样式放到 `aeallpattern` 命名空间，并在 `ClientEvents.registerScreens()` 中直接注册新样式路径。

## 接入说明

`integration/mixins.fragment.json` 包含相关 Mixin 注册片段。

`integration/mixin-plugin.fragment.java` 包含可选模组和目标类存在性检查片段。

这些源码使用到的依赖包括：

- AE2
- AE All Pattern
- MixinExtras
- EMI
- TooManyRecipeViewers
- JEI
- AE2 JEI Integration（用于转换已注册的自定义原料，包括受支持的 Mekanism 化学品）

GoldenTweaks 项目已在包含这些修改的情况下通过 `gradlew build`。
